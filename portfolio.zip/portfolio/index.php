<?php
// index.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Portfolio | Zildan Surya Permana</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Emergency fix untuk intro */
        .intro-removed {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
        }
    </style>
</head>
<body>

<!-- Background Effects Container -->
<div id="background-effects">
    <!-- RGB Lights -->
    <div class="rgb-light light-1"></div>
    <div class="rgb-light light-2"></div>
    
    <!-- Pulsing Dots -->
    <div class="pulsing-dot dot-1"></div>
    <div class="pulsing-dot dot-2"></div>
    <div class="pulsing-dot dot-3"></div>
</div>

<!-- INTRO / SPLASH - PASTIKAN ADA ID "intro" -->
<div id="intro">
  <div class="intro-card">
    <h1 id="intro-name">Zildan Surya Permana</h1>
    <p class="sub">Web Developer • UI/UX Enthusiast</p>
    <div class="loading-bar"></div>
  </div>
</div>

<!-- HERO SECTION -->
<header class="hero" id="home">
  <div class="hero-inner">
    <h2 class="eyebrow">Halo 👋</h2>
    <h1 class="hero-title">Saya <span class="accent">Zildan Surya Permana</span> — Web Developer</h1>
    <p class="lead">Membuat website rapi, cepat, dan berfokus pada pengalaman pengguna dengan sentuhan modern dan minimalis.</p>
    <a href="#about" class="btn ghost">Jelajahi Portfolio</a>
  </div>
</header>

<!-- ABOUT -->
<section id="about" class="panel">
  <div class="container">
    <h2>Tentang Saya</h2>
    <p>Saya adalah mahasiswa yang passionate di bidang pengembangan web dan desain antarmuka. Saat ini sedang mencari kesempatan <strong>magang sebagai Web Developer / UI Designer</strong> untuk mengembangkan skill dan berkontribusi pada proyek nyata.</p>
    <p>Terbiasa bekerja dengan teknologi modern seperti <strong>HTML5, CSS3, PHP, MySQL, JavaScript</strong>, dan memiliki pemahaman dasar tentang prinsip-prinsip <strong>UI/UX Design</strong> untuk menciptakan pengalaman pengguna yang optimal.</p>
  </div>
</section>

<!-- SKILLS -->
<section id="skills" class="panel panel--muted">
  <div class="container">
    <h2>Skill & Teknologi</h2>
    <div class="skills-list">
      <div class="skill"><span class="dot"></span> HTML5 & Semantic Markup</div>
      <div class="skill"><span class="dot"></span> CSS3 & Modern Layouts</div>
      <div class="skill"><span class="dot"></span> PHP & Backend Basics</div>
      <div class="skill"><span class="dot"></span> MySQL Database</div>
      <div class="skill"><span class="dot"></span> Responsive Web Design</div>
      <div class="skill"><span class="dot"></span> UI/UX Fundamentals</div>
      <div class="skill"><span class="dot"></span> Version Control (Git)</div>
      <div class="skill"><span class="dot"></span> Web Performance</div>
    </div>
  </div>
</section>

<!-- PROJECTS -->
<section id="projects" class="panel">
  <div class="container">
    <h2>Proyek Terbaru</h2>
    <div class="project-grid">
      <a class="project-card" href="https://pemdesgandasoli.com" target="_blank">
        <div class="project-media"></div>
        <div class="project-body">
          <h3>Website Desa Digital</h3>
          <p>Website informasi desa berbasis PHP dengan sistem admin panel untuk mengelola konten secara dinamis.</p>
        </div>
      </a>

      <a class="project-card" href="project-landing.html">
        <div class="project-media"></div>
        <div class="project-body">
          <h3>Landing Page Portfolio</h3>
          <p>Landing page modern dan responsif dengan performa tinggi menggunakan HTML & CSS murni.</p>
        </div>
      </a>
      
      <a class="project-card" href="#">
        <div class="project-media"></div>
        <div class="project-body">
          <h3>UI Dashboard Design</h3>
          <p>Konsep desain dashboard admin dengan komponen modern dan palet warna yang user-friendly.</p>
        </div>
      </a>
    </div>
  </div>
</section>

<!-- CONTACT -->
<section id="contact" class="panel panel--muted">
  <div class="container">
    <div class="contact">
      <h2>Hubungi Saya</h2>
      <p>Saya terbuka untuk peluang magang, kolaborasi proyek, atau diskusi seputar pengembangan web.</p>
      <p><strong>Email:</strong> <a href="mailto:zildan.surya_ti23@nusaputra.co.id">zildan.surya_ti23@nusaputra.co.id</a></p>
      <p><strong>GitHub:</strong> <a href="https://github.com/zan45a" target="_blank">github.com/zan45a</a></p>
      <div style="margin-top: 3rem;">
        <a href="mailto:zildan@email.com" class="btn">Kirim Pesan</a>
      </div>
    </div>
  </div>
</section>

<footer>
  <div class="container footer-inner">
    © 2025 Zildan Surya Permana — Crafted with passion & modern design
  </div>
</footer>

<script src="js/script.js"></script>
<script>
    // Emergency fallback - hapus intro jika stuck
    window.addEventListener('load', function() {
        console.log('Emergency fix running...');
        
        // Otomatis hapus intro setelah 5 detik
        setTimeout(function() {
            var intro = document.getElementById('intro');
            if (intro) {
                console.log('Removing intro (emergency)...');
                intro.classList.add('intro-removed');
                intro.style.display = 'none';
            }
        }, 5000);
        
        // Force enable scrolling
        document.body.style.overflow = 'auto';
        document.documentElement.style.overflow = 'auto';
    });
</script>
</body>
</html>
[file content end]