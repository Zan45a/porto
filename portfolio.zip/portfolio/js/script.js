// SIMPLE Star Field Generator
function initStarField() {
    const container = document.getElementById('background-effects');
    if (!container) return;
    
    // Create stars
    for (let i = 0; i < 80; i++) {
        const star = document.createElement('div');
        star.className = 'floating-star';
        
        // Random star size
        const sizes = ['tiny', 'small', 'medium'];
        const size = sizes[Math.floor(Math.random() * sizes.length)];
        star.classList.add(`star-${size}`);
        
        // Random speed
        const speeds = ['star-slow', 'star-very-slow'];
        const speed = speeds[Math.floor(Math.random() * speeds.length)];
        star.classList.add(speed);
        
        // Random position
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        
        // Random animation delay
        star.style.animationDelay = `${Math.random() * 60}s`;
        
        container.appendChild(star);
    }
}

// Main initialization
document.addEventListener('DOMContentLoaded', function() {
    // ===== INTRO ANIMATION =====
    const intro = document.getElementById('intro');
    
    setTimeout(function() {
        if (intro) {
            intro.classList.add('hidden');
        }
    }, 3000);

    // ===== INITIALIZE STAR FIELD =====
    initStarField();

    // ===== SMOOTH SCROLL =====
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#' || href === '#home') {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
                return;
            }
            
            const targetElement = document.querySelector(href);
            if (targetElement) {
                e.preventDefault();
                const offsetTop = targetElement.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Scroll progress
    window.addEventListener('scroll', () => {
        const scrollProgress = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
        document.documentElement.style.setProperty('--scroll-progress', `${scrollProgress}%`);
    });
});