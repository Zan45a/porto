<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Project | Website Desa Digital</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav>
    <div class="logo">Zildan</div>
    <ul>
        <li><a href="index.php">← Kembali</a></li>
    </ul>
</nav>

<section class="project-detail">
    <h1>Website Desa Digital</h1>

    <p class="project-desc">
        Website Desa Digital merupakan website informasi desa yang dibuat
        untuk menampilkan profil desa, berita, galeri, dan layanan publik.
        Website ini dibangun menggunakan PHP dan CSS dengan tampilan modern
        dan mudah digunakan oleh masyarakat.
    </p>

    <div class="project-info">
        <p><strong>Teknologi:</strong> PHP, HTML, CSS</p>
        <p><strong>Peran:</strong> Web Developer & UI Designer</p>
    </div>

    <a href="https://pemdesgandasoli.com" target="_blank" class="btn-project">
        🔗 Kunjungi Website
    </a>
</section>

<footer>
    <p>© 2025 Zildan</p>
</footer>

</body>
</html>
